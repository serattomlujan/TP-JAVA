package Data;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import Entity.Categoria;


public class DataCategoria {
public ArrayList<Categoria> getAll() throws Exception{

	Statement stmt=null;
	ResultSet rs=null;
	ArrayList<Categoria> cats= new ArrayList<Categoria>();
	try{
		stmt = FactoryConexion.getInstancia().getConn().createStatement();
		rs = stmt.executeQuery("select id_categoria, descripcion from categorias");
		if(rs!=null){
			while(rs.next()){
				Categoria c=new Categoria();
				c.setId_categoria(rs.getInt("id_categoria"));
				c.setDescripcion(rs.getString("descripcion"));
				cats.add(c);
				}
			}
		} catch (Exception e){
			throw e;
		}
		
		try {
			if(rs!=null) rs.close();
			if(stmt!=null) stmt.close();
			FactoryConexion.getInstancia().releaseConn();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return cats;
	}
}